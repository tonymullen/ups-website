/**
 * This class creates keyboards with different arrangements and computes 
 * the number of key presses required for different pieces of text.
 * @author YOUR NAME
 * @version THE DATE
 */
public class Controller {

    // The pieces of text to enter
    private static final String TEXT1 = "Harry Potter".toLowerCase().replaceAll("[^A-Za-z0-9\\s]", "");    

    private static final String TEXT2 = "Dr Strangelove or How I Learned to Stop Worrying and Love the Bomb".toLowerCase().replaceAll("[^A-Za-z0-9\\s]", "");    
    
    private static final String TEXT3 = "The quick brown fox jumped over the lazy dog.".toLowerCase().replaceAll("[^A-Za-z0-9\\s]", "");
    
    private static final String LONG_TEXT = "Call me Ishmael. Some years ago--never mind how long precisely--having "+
        "little or no money in my purse, and nothing particular to interest me on "+
        "shore, I thought I would sail about a little and see the watery part of "+
        "the world. It is a way I have of driving off the spleen and regulating "+
        "the circulation. Whenever I find myself growing grim about the mouth; "+
        "whenever it is a damp, drizzly November in my soul; whenever I find "+
        "myself involuntarily pausing before coffin warehouses, and bringing up "+
        "the rear of every funeral I meet; and especially whenever my hypos get "+
        "such an upper hand of me, that it requires a strong moral principle to "+
        "prevent me from deliberately stepping into the street, and methodically "+
        "knocking people's hats off--then, I account it high time to get to sea "+
        "as soon as I can. This is my substitute for pistol and ball. With a "+
        "philosophical flourish Cato throws himself upon his sword; I quietly "+
        "take to the ship. There is nothing surprising in this. If they but knew "+
        "it, almost all men in their degree, some time or other, cherish very "+
        "nearly the same feelings towards the ocean with me.".toLowerCase().replaceAll("[^A-Za-z0-9]\\s", "");
    
    // These keyboards
    private static final String KEYS1 = "abcdefghijklmnopqrstuvwxyz 0123456789";
    private static final String KEYS2 = "qwertyuiopasdfghjklzxcvbnm 0123456789";          
    
    /**
     * This method takes a keyboard and a piece of text and it prints
     * the number of key presses required
     * @param board A keyboard
     * @param input A piece of text
     */
    private static void test(Keyboard board, String input) {
        System.out.println("It took " + board.pressesRequired(input) + " key presses to type");
        System.out.println("\""+ input + "\" using this key arrangement:");
        System.out.println(board);
        System.out.println("=======================\n");
    }

    
    public static void main(String[] args) {
        // Testing "Harry Potter"
        test(new Keyboard(KEYS1, 10), TEXT1);
        test(new Keyboard(KEYS1, KEYS1.length()), TEXT1);
        test(new Keyboard(KEYS2, 10), TEXT1);
        test(new Keyboard(KEYS2, KEYS2.length()), TEXT1);
        
        // Testing "Dr. Strangelove"
        System.out.println();
        test(new Keyboard(KEYS1, 10), TEXT2);
        test(new Keyboard(KEYS1, KEYS1.length()), TEXT2);
        test(new Keyboard(KEYS2, 10), TEXT2);
        test(new Keyboard(KEYS2, KEYS2.length()), TEXT2);
        
        // Testing "The quick brown fox..."
        System.out.println();        
        test(new Keyboard(KEYS1, 10), TEXT3);
        test(new Keyboard(KEYS1, KEYS1.length()), TEXT3);
        test(new Keyboard(KEYS2, 10), TEXT3);
        test(new Keyboard(KEYS2, KEYS2.length()), TEXT3);
        
        // FILL IN HERE:
        // COME UP WITH YOUR OWN KEYBOARD CONFIGURATION THAT REQUIRES FEWER KEY PRESSES
        // THAN KEYS1 AND KEYS2 ON THE LONG_TEXT
    }
}

 