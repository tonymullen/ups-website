/**
 * Theater represents the theater with
 * a name and a list of rows of seats.
 * 
 * @author Tony Mullen
 * @version 1.0
 */

import java.util.ArrayList;

public class Theater
{
    private String theaterName;
    private ArrayList<ArrayList<Seat>> rows = new ArrayList<ArrayList<Seat>>();
    
    /**
    * Constructor for objects of class Theater
    */
    public Theater(String theaterName, int rowNum)
    {
        this.theaterName = theaterName;
        int i = 0;
        while (i < rowNum){
            rows.add(new ArrayList<Seat>());
            rows.get(i).add(new Seat("A"));
            rows.get(i).add(new Seat("B"));
            rows.get(i).add(new Seat("C"));
            rows.get(i).add(new Seat("D"));
            rows.get(i).add(new Seat("E"));
            rows.get(i).add(new Seat("F"));
            rows.get(i).add(new Seat("G"));
            rows.get(i).add(new Seat("H"));
            rows.get(i).add(new Seat("I"));
            rows.get(i).add(new Seat("J"));
            i++;
        }
    }
    
    
    /**
     * Gets the list of rows
     * 
     * @return     the list of rows
     */
    public ArrayList<ArrayList<Seat>> getRows(){
        return this.rows;
    }
    
    /**
     * Gets the number of vacancies for a row
     * 
     * @param rowNum    the row number
     * @return          the number of vacant seats in that row
     */
    public int getVacancies(int rowNum){
        int vacs = 0;
        int i = 0;
        while (i < rows.get(rowNum).size()){
            if (rows.get(rowNum).get(i).getReservedFor() == null){
                vacs++;
            }
            i++;
        }
        return vacs;
    }

    /**
     * Gets the theater name
     * 
     * @return          the theater name
     */
    public String getName(){
        return this.theaterName;
    }

    /**
     * Gets the number of rows in the theater
     * 
     * @return          the number of rows
     */
    public int getRowCount(){
        return this.rows.size();
    }
    
    public String toString(){
        String str = "";
        int i = 0;
        while (i < this.rows.size()){
            int j = 0;
            if(i < 10){
                str = str + " " + i;
            }else{
                str = str + i;
            }
            str = str + " ";
            while(j < this.rows.get(i).size()){
                if(this.rows.get(i).get(j).getReservedFor() == null){
                    str = str + "_ ";
                }else{
                    str = str + "X ";
                }
                j++;
            }
            str = str + "\n";
            i++;
        }
        return str;
    }
}
