/**
 * Reservations allows the user to make
 * seat reservations in a theater
 * 
 * @author Tony Mullen
 * @version 1.0
 */

import java.util.ArrayList;
import java.util.Scanner;

public class Reservations
{
    Theater theater = new Theater("Roxy", 15);
    Scanner scan = new Scanner(System.in);
    
     /**
     * Executes the interactive service
     */
    public void runService()
    {
        int bestRow = theater.getRowCount()/2;
        String cmd   = new String();
        
        while(!cmd.equalsIgnoreCase("done"))
        {
            System.out.println("What would you like to do?");
            cmd = scan.next();
            if (cmd.equalsIgnoreCase("reserve"))
            {
                int num = scan.nextInt();
                scan.nextLine();
                Boolean booked = false;
                
                /*
                 * distFromBest is the number of seats away from the middle row.
                 * We look for empty seats in the rows behind the middle row and then
                 * in front of the middle row, and increase distFromBest as necessary
                 * until we find sufficient seats. 
                 */
                int distFromBest = 0;
                while (!booked && (distFromBest <= bestRow)) {
                    if (num <= theater.getVacancies(bestRow - distFromBest)){
                        bookIntoRow(bestRow - distFromBest, num);
                        booked = true;
                    } else if (num <= theater.getVacancies(bestRow + distFromBest)){
                        bookIntoRow(bestRow + distFromBest, num);
                        booked = true;
                    }
                    else {
                        distFromBest++;
                    }
                }
                if(!booked) {
                    System.out.println("Sorry, we don't have that many seats together for you.");
                }
            }
            else if (cmd.equalsIgnoreCase("show"))
            {
                System.out.println(theater);
            }
            
        }
        System.out.println("Have a nice day!");
    }
    
    /*
     * This method books seats into a particular row
     * 
     * @param rowNum    the row to book into
     * @param num       the number of seats to book
     */
    private void bookIntoRow(int rowNum, int num){
         System.out.println("What's your name?");
         String name = scan.nextLine();
                    
         int i = 0;
         int r = num;
                    
         while( i < theater.getRows().get(rowNum).size() && r > 0){
           if(theater.getRows().get(rowNum).get(i).getReservedFor() == null){
               theater.getRows().get(rowNum).get(i).reserveFor(name);
               r--;
           }
           i++;
         }   
         
         System.out.println("I've reserved " + num 
                          + " seats for you at the "  
                          + theater.getName() 
                          + " in row " + rowNum
                          + ", " + name +".");       
    }
}
