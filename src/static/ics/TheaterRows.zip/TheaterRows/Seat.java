/**
 * Seat represents a single seat
 * it has a alphabetical seat number
 * and a "reservedFor" attribute 
 * representing the name of the person
 * who has reserved the seat (or null, if 
 * the seat is vacant.
 * 
 * @author Tony Mullen
 * @version 1.0
 */

public class Seat
{
    private String seatNo;
    private String reservedFor;
    
    public Seat(String seatNo)
    {
        this.seatNo = seatNo;
    }

    public String getReservedFor()
    {
        return this.reservedFor;
    }
    
    public void reserveFor(String name)
    {
        this.reservedFor = name;
    }
    
    public String toString(){
        String str = "Seat " + seatNo;
        if(this.reservedFor == null){
            str = str + " is available.";
        }
        else
        {
            str = str + " is reserved for " + this.reservedFor + ".";
        }
        return str;
    }
}
