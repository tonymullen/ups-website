/**
 * The Calculator class models a four-function calculator.
 */

public class Calculator
{
    double displayValue;  // The value that would be in the display

    /** 
     * This method adds n to the calculator's current value, and stores
     * the result back in displayValue.  An output message is printed,
     * describing how the value's been updated.
     */
    public void add(double n) {
        double original = displayValue;  // Store original val for display later
        displayValue = displayValue + n;
        System.out.println(original+" + "+n+" = "+displayValue);
    }

    /** 
     * This method subtracts n from the calculator's current value, and 
     * stores the result back in displayValue.  An output message is
     * printed, describing how the value's been updated.
     */
    public void subtract(double n) {
        // Print part of the message before changing value
        System.out.print(displayValue+" - "+n+" = ");
        displayValue = displayValue - n;
        // Now print the rest of the message
        System.out.println(displayValue);
    }

    /** 
     * This method multiplies the calculator's current value by n, and 
     * stores the result back in displayValue.  An output message is
     * printed, describing how the value's been updated.
     */
    public void multiply(double n) {
        System.out.print(displayValue+" * "+n+" = ");
        displayValue = displayValue * n;
        System.out.println(displayValue);
    }
}
