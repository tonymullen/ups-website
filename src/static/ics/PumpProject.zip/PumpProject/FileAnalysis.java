import java.util.ArrayList;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class FileAnalysis
{

    public FileAnalysis(String nameOfFile) throws FileNotFoundException {
        // Fill this in
    }
    

    public double totalHours() {
        // Fill this in
    }   
    

    public double totalPower() {
        // Fill this in
    }    
    
    
    public int minutesPumping() {
        // Fill this in
    }
    

    public int minutesToPumpAmount(double gallonAmount) {
        // Fill this in
    }

}
