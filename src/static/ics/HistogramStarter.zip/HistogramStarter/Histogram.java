/**
 * Histogram reads a file of numbers and displays
 * frequencies as rows of asterisks.
 * 
 * @author Tony Mullen
 */

import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;

public class Histogram
{
    /*
     * declare an array instance value to hold the necessary 
     * counts.
     */
    
    /**
     * Constructor for objects of class Histogram
     */
    public Histogram(String nameOfFile) throws FileNotFoundException{
        File file = new File(nameOfFile);
        Scanner scan = new Scanner(file);
        while(scan.hasNext()){
            /*
             * Here's where your code will go to collect the counts
             * 
             */
        }
        
        /*
         * Write the code to display the histogram with asterisks 
         * representing the times the values occurred in the data
         */
    }
}
