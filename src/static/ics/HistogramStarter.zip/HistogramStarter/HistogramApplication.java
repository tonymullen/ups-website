import java.io.FileNotFoundException;

/**
 * HistogramApplication creates an 
 * instance of Histogram to read a specific
 * text file.
 * 
 * @author Tony Mullen
 */
public class HistogramApplication
{
    public static void main(String[] args){
        String fileName = "numbers.txt";
        try {
            Histogram hg = new Histogram(fileName);
        }
        catch (FileNotFoundException ex)  {
            System.out.print("Can't open "+fileName+"\n");
        }
    }
}
