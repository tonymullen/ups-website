import java.util.Scanner;
import java.util.Random;

public class Passwords
{

    public static void main(String[] args) {
        
        // Add your code here
        
    }
}