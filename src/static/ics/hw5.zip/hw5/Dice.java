
/**
 * This class represents a pair of dice.
 * It should have a constructor that creates a new pair of dice
 * with default number of sides (6), a constructor that creates 
 * a new pair of dice which share an arbitrary number of sides, 
 * and a constructor that creates two dice, each with an arbitrary
 * number of sides that aren't necessarily the same. 
 * 
 * It should have a roll() method that rolls the two dice and reports
 * the value of each die and the total, and records the average of all
 * rolls of the pair so far. 
 * 
 * It should have a method called reportAverage() that prints out the
 * average value of all rolls so far. 
 * 
 * See the DiceRoller class for details on how this class will be called. 
 * You should not need to modify DiceRoller or the Die class included with 
 * this project. 
 */

public class Dice
{

}
