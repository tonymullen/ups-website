/*
 * This class creates an object representing a *pair* of 
 * Dice, then rolls them several times and reports the average
 * result. 
 */
public class DiceRoller

{
    
   public static void main(String[] args)
   {
      //this creates a new pair of 6 sided dice
      Dice dicePair1 = new Dice();
      
      //this creates a new pair of 20 sided dice
      Dice dicePair2 = new Dice(20);
      
      //this creates a new pair of dice, one with 6 sides and one with 20 sides
      Dice dicePair3 = new Dice(6, 20);
      
      dicePair1.roll();
      dicePair1.roll();
      dicePair1.reportAverage();
      
      dicePair2.roll();
      dicePair2.roll();
      dicePair2.roll();
      dicePair2.reportAverage();
      
      dicePair3.roll();
      dicePair3.roll();
      dicePair3.roll();
      dicePair3.roll();
      dicePair3.reportAverage();
   }
}
