
public class AsteriskPictures{
    
    /**
     * Draw a square with the given dimensions
     * @param numRows The number of rows
     * @param numCols The number of cols
     */
    private static void square(int numRows, int numCols){
        // FILL IN
    }
    
    /**
     * Draw a triangle with the given dimensions
     * @param height The height of the triangle
     */
    private static void triangle(int height){
        // FILL IN
    }        
    
    /**
     * Call (i.e. invoke) your methods from inside the main method
     */
    public static void main(String[] args){
               
    }       
}
