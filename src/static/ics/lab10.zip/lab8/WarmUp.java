

public class WarmUp{

    /**
     * Prints "Hello world!" to the screen 10 times
     */
    private static void printHello(){
        // FILL IN
    }
    
    
    /**
     * Sums the first n whole numbers
     * @param n the upper bound of the summation
     * @return the sum 1+2+...+n
     */
    private static int sum(int n){
        // FILL IN
    }
        
    /**
     * Prints random numbers between 1 and the upper bound
     * @param numValues the number of random values to print
     * @param upperBound the upper bound of the random values
     */
    private static void randomNumbers(int numValues, int upperBound){
        // FILL IN
    }
    
    /**
     * Prints the even integers between 0 and the upperBound (inclusive if the
     * upperBound itself is an even integer)
     * @param upperBound the upper bound of values to print
     */
    private static void evenNumbers(int upperBound){
        // FILL IN
    }
    
    /**
     * Reads an entire line of input from the user and 
     * prints the input to the screen in reverse order 
     */
    private static void reverseString(){
        // FILL IN
    }
    
    /**
     * Reads an entire line of input from the user and 
     * prints each word on a separate line 
     */
    private static void tokenize(){
        // FILL IN        
    }
    
    /**
     * Call (i.e. invoke) your methods from inside the main method
     */    
    public static void main(String[] args){
        
    }
}
