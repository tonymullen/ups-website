import java.util.ArrayList;

public class Theater
{
    private String theaterName;
    private ArrayList<ArrayList<Seat>> rows = new ArrayList<ArrayList<Seat>>();
    
    public Theater(String theaterName, int rowNum)
    {
        this.theaterName = theaterName;
        int i = 0;
        while (i < rowNum){
            rows.add(new ArrayList<Seat>());
            rows.get(i).add(new Seat("A"));
            rows.get(i).add(new Seat("B"));
            rows.get(i).add(new Seat("C"));
            rows.get(i).add(new Seat("D"));
            rows.get(i).add(new Seat("E"));
            rows.get(i).add(new Seat("F"));
            rows.get(i).add(new Seat("G"));
            rows.get(i).add(new Seat("H"));
            rows.get(i).add(new Seat("I"));
            rows.get(i).add(new Seat("J"));
            i++;
        }
    }
    
    public ArrayList<ArrayList<Seat>> getRows(){
        return this.rows;
    }
    
    public int getVacancies(int rowNum){
        int vacs = 0;
        int i = 0;
        while (i < rows.get(rowNum).size()){
            if (rows.get(rowNum).get(i).getReservedFor() == null){
                vacs++;
            }
            i++;
        }
        return vacs;
    }
 
    public String getName(){
        return this.theaterName;
    }
    
    public int getRowCount(){
        return this.rows.size();
    }
    
    public String toString(){
        String str = "";
        
        /*
         * TODO: Implement the toString() method here
         * such that it outputs a diagram of the theater
         * seats, with empty seats displayed as _s and
         * occupied seats displayed as Xs, also, have
         * it label each row with its corresponding number.
         */
        
        return str;
    }
}
