import java.util.ArrayList;
import java.util.Scanner;

public class Reservations
{
    /*
     * The theater constructor call is hard coded here, 
     * but as you can see we could easily extend this code
     * to deal with different theaters with different numbers
     * of rows.
     */
    Theater theater = new Theater("Roxy", 15);
    Scanner scan = new Scanner(System.in);
    
    public void runService()
    {
        String cmd   = new String();
        
        while(!cmd.equalsIgnoreCase("done"))
        {
            System.out.println("What would you like to do?");
            cmd = scan.next();
            if (cmd.equalsIgnoreCase("reserve"))
            {
                int num = scan.nextInt();
                scan.nextLine();
                /*
                 * TODO: Here's where you'll put the main reservation code.
                 * Find the optimal row (ie. the row nearest the middle) that
                 * has a sufficient number of adjacent seats, then reserve the
                 * seats from left to right across the row. 
                 * 
                 * You may add any necessary instance variables or make use of
                 * any private or public methods, for example the bookIntoRow 
                 * method started below.
                 */
            }
            else if (cmd.equalsIgnoreCase("show"))
            {
                System.out.println(theater);
            }
            
        }
        System.out.println("Have a nice day!");
    }
    
    private void bookIntoRow(int rowNum, int num){
         System.out.println("What's your name?");
         String name = scan.nextLine();
         
         /*
          * TODO: Complete this method to book num seats 
          * in a specific row (rowNum).
          */
         
         System.out.println("I've reserved " + num 
                          + " seats for you at the "  
                          + theater.getName() 
                          + " in row " + rowNum
                          + ", " + name +".");       
    }
}
