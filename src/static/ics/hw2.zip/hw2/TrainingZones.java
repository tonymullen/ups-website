import java.util.Scanner;

public class TrainingZones{
    public static void main(String[] args){
        // This allows us to read in whatever the user types at the keyboard
        Scanner input = new Scanner(System.in);
        
        System.out.println("Please enter your age:");
        int age = input.nextInt();
        
        System.out.println("Please enter your resting heart rate:");
        int restHR = input.nextInt();
  
        
        // TODO: Fill in the rest of this class
    }   
}