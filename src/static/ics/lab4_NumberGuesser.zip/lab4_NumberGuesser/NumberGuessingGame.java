/**
 * The number guessing game.
 */

// TODO: import any necessary libraries

public class NumberGuessingGame
{   
    private final int MAX = 50;
    private int secretNumber;
    
    // TODO: write a constructor for the object that sets
    // secretNumber to a random value between 1 and MAX. 
    
    public void play()
        {
          // TODO: initialize a scanner object. 
            
          // TODO: declare variables to hold the guessed
          // number and the number of tries.
      
          // TODO: fill in the while loop and conditionals
          // below (currently it's commented out so the 
          // code will compile. 
          
          /*
          while () 
                {

                    if ()
                    {

                    } 
                    else
                    {

                    }
                }
          */
          // What should go here?
    }
}
