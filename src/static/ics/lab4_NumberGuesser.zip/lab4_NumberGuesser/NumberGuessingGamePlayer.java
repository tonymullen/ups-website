/**
 * The Number Game Player application
 * 
 * @author tmullen
 */

public class NumberGuessingGamePlayer
{   
    public static void main(String[] args)
    {
        NumberGuessingGame ngGame = new NumberGuessingGame();
        ngGame.play();
    }
}
