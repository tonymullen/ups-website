/**********************************************************************
 *  README.txt
 *  CS315 - Homework 1: Learning Three.js Chapter 1
 **********************************************************************/

/**********************************************************************
* What is your name?
***********************************************************************/

<Replace this with your response--remember to delete the angle brackets>



/**********************************************************************
* What browser and operating system did you test your program with?
***********************************************************************/

<Replace this with your response>



/**********************************************************************
* Approximately how many hours did you spend working on this assignment?
***********************************************************************/

<Replace this with your response!>



/**********************************************************************
 * Describe any problems you encountered in this assignment.
 * What was hard, or what should we warn students about in the future?
 * How can I make this assignment better?
 **********************************************************************/

<Replace this with your response!>



/**********************************************************************
 * List any other comments (about the assignment or your submission)
 * here. Feel free to provide any feedback on what you learned from
 * doing the assignment, whether you enjoyed doing it, etc.
 **********************************************************************/

<Replace this with your response!>
