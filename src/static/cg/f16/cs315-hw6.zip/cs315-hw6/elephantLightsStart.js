////////////////////////////////////////////////////////////////////////////////
/*global THREE, document, window  */
var camera, scene, renderer;
var cameraControls, controls, gui;

var clock = new THREE.Clock();
var camX, camZ;
var rot = 0;
var camDistance = 1200;

/*
TODO: Instead of one white spotlight, you'll need separate
spotlights for each of the R, G, and B components. You can
declare and initialize these here.
*/
var spotLight = new THREE.SpotLight( 0xffffff);

function fillScene() {
	scene = new THREE.Scene();

	/*
	Here's the GUI control code. This creates an
	object called controls with a property called lightSeparation.
	You can use controls.lightSeparation elsewhere in your code to
	control the distance between your colored lights.

	To control the spotlights' target position, you'll need to add another
	property to controls called 'target'. Have it range from 0.0 to 1.0 just
	like this one, and use it as a factor to multiply a displacement in
	the render function.
	*/
	gui = new dat.GUI({
		autoPlace: false,
		height : (32 * 1)- 1
	});
	controls = {
		lightSeparation: 1.0
	};

	gui.add(controls, 'lightSeparation', 0, 1.0);

	gui.domElement.style.position = "relative";
	gui.domElement.style.top = "-400px";
	gui.domElement.style.left = "350px";


	/*
	TODO: Here's where the light gets set up for the first time.
	You'll need to set up each of your colored lights similarly, to
	replace the current white light.
	*/

	spotLight.position.set( 0, 1500, 800 );
	spotLight.angle = 25 * Math.PI/180;
	spotLight.penumbra = 0.20;
	spotLight.distance = 2500;
	spotLight.intensity = 3;
	spotLight.castShadow = true;

	spotLight.shadow.mapSize.width = 1024;
	spotLight.shadow.mapSize.height = 1024;

	spotLight.shadow.camera.near = 1;
	spotLight.shadow.camera.far = 2000;

	scene.add( spotLight );
	/*
	The spotLight.target object must be added to the
	scene in order to use it. It can be positioned like any
	other object, and it determines the direction that the
	spotlight points. The default target position is (0,0,0).
	*/
	scene.add( spotLight.target );

	/*
	These helpers are useful to see the spotlight and
	shadow camera's location, angle, and dimensions. Uncomment
	them to see how they work.
	*/
	/*
	var spotLightHelper = new THREE.SpotLightHelper( spotLight );
	scene.add( spotLightHelper  );
	var shadowHelper = new THREE.CameraHelper( spotLight.shadow.camera );
	scene.add( shadowHelper );
	*/


	//grid xz
	var gridXZ = new THREE.GridHelper(2000, 100, new THREE.Color(0xCCCCCC), new THREE.Color(0x888888) );
	scene.add(gridXZ);

	drawElephant();
}

function drawElephant() {


	var manager = new THREE.LoadingManager();
	manager.onProgress = function ( item, loaded, total ) {
		console.log( item, loaded, total );
	};

	var onProgress = function ( xhr ) {
		if ( xhr.lengthComputable ) {
			var percentComplete = xhr.loaded / xhr.total * 100;
			console.log( Math.round(percentComplete, 2) + '% downloaded' );
		}
	};
	var onError = function ( xhr ) {
	};

	var elephantTex = new THREE.Texture();
	var planeTex = new THREE.Texture();

	var loader = new THREE.ImageLoader( manager );
	loader.load( 'elephantColor.jpg', function ( image ) {
		elephantTex.image = image;
		elephantTex.needsUpdate = true;
	} );

	loader = new THREE.OBJLoader( manager );
	loader.load( 'elephantcomplete.obj', function ( object ) {
		object.traverse( function ( child ) {
			if ( child instanceof THREE.Mesh ) {
				child.material.map = elephantTex;
				child.castShadow = true;
			}
		} );
		object.position.y = 500;
		scene.add( object );
	}, onProgress, onError );

	loader = new THREE.ImageLoader( manager );
	loader.load( 'tex.jpg', function ( image ) {
		planeTex.image = image;
		planeTex.needsUpdate = true;
	} );

	loader = new THREE.OBJLoader( manager );
	loader.load( 'plane.obj', function ( object ) {
		object.traverse( function ( child ) {
			if ( child instanceof THREE.Mesh ) {
				child.material.map = planeTex;
				child.receiveShadow = true;
			}
		} );
		object.position.y = 500;
		scene.add( object );
	}, onProgress, onError );

}

function init() {
	var canvasWidth = 600;
	var canvasHeight = 400;
	var canvasRatio = canvasWidth / canvasHeight;

	// RENDERER
	renderer = new THREE.WebGLRenderer( { antialias: true } );

	renderer.setSize(canvasWidth, canvasHeight);
	renderer.setClearColor( 0x000000 );
	renderer.shadowMap.enabled = true;
	renderer.shadowMap.type = THREE.PCFSoftShadowMap;

	// CAMERA
	camera = new THREE.PerspectiveCamera( 45, canvasRatio, 1, 10000 );
	camera.position.set( -camDistance, 1000, camDistance);

	// CONTROLS
	cameraControls = new THREE.OrbitControls(camera, renderer.domElement);
	cameraControls.target.set(0,480,0);
}

function addToDOM() {
    var canvas = document.getElementById('canvas');
    canvas.appendChild(renderer.domElement);
		canvas.appendChild(gui.domElement);
}

function animate() {
	window.requestAnimationFrame(animate);
	render();
}

function render() {
	var delta = clock.getDelta();

	/*
	TODO: You can animate the positioning of your lights here.
	Use the controls.lightSeparation property to make your light positions
	dependent on values from the gui controller. Use controls.target (which
	you also need to create) to change the position of the target up and down
	along the y axis (the target shouldn't move on other dimensions).

	Each light object and target object has a position attribute which can be
	set using the set() method. Use that method to (re) position your lights and
	target on each render call.
	*/

	cameraControls.update(delta);
	renderer.render(scene, camera);
}

try {
  init();
  fillScene();
  addToDOM();
  animate();
} catch(error) {
    console.log("Your program encountered an unrecoverable error, can not draw on canvas. Error was:");
    console.log(error);
}
